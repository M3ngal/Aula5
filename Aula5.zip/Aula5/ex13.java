import java.util.Scanner;

public class ex13 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int p = 0;
        while(true) {
            System.out.printf("Insira um número: ");
            int a = sc.nextInt();
            if (a < 0) {
                break;
            }
            if (a < 2) {
                continue;
            }
            if (a == 2) {
                p++;
                continue;
            }
            for (int i = 2; i <= Math.sqrt(a); i++) {
                if (a % i == 0) {
                    break;
                }
                continue;
            }
            p++;
        }
        System.out.printf("Primos: " + p);
        sc.close();
    }
}