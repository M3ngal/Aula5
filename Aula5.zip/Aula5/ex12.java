import java.util.Scanner;

public class ex12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int p = 0;
        System.out.printf("Insira um número: ");
        int a = sc.nextInt();
        if (a < 2) {
            p++;
        }
        for (int i = 2; i <= Math.sqrt(a); i++) {
            if (a % i == 0) {
                p++;
            }
        }
        if(p == 1){
            System.out.printf("Não é primo");
        }
        else{
            System.out.printf("É primo");
        }
        sc.close();
    }
}