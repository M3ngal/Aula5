import java.util.Scanner;

public class ex3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int a = -1;
        int b = 0;
        System.out.printf("Insira um número: ");
        while((a = sc.nextInt()) != 0){
            System.out.printf("Insira um número: "); 
            if(a > 100 && a < 200){
                b++;
            }
        }
        System.out.printf("Há %d números entre 100 e 200", b);
        sc.close();
    }
}