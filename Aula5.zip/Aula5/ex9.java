import java.util.Scanner;

public class ex9 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double a;
        System.out.printf("Insira um número: ");
        while((a = sc.nextDouble()) != -999){
            System.out.printf("Divisores: \n"); 
            for(int i = 1; i<=a;i++){ 
                if((a%i) == 0)
                System.out.printf(i + "\n");
            }
            System.out.printf("Insira um número: "); 
            }
        sc.close();
        }
    }