import java.util.Scanner;

public class ex10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double t1 = 0;
        double t2 = 0;
        double t3 = 0;
        double m1 = 0;
        double m2 = 0;
        while(true) {
            System.out.printf("Insira o código do cliente: ");
            int a = sc.nextInt();
            if(a == 0){
                break;
            }
            System.out.printf("Insira quantidade de kWh consumidos durante o mês: ");
            double b = sc.nextDouble();
            System.out.printf("Insira o tipo de consumidor(1|2|3): ");
            int c = sc.nextInt();
            if(c == 1){
                b = b * 0.3;
                t1 += b;
                m1++;
                System.out.printf("Total do cliente: " + b + "\n");
            }
            else if(c == 2){
                b = b * 0.5;
                t2 += b;
                m2++;
                System.out.printf("Total do cliente: " + b + "\n");
            }
            else if(c == 3){
                b = b * 0.7;
                t3 += b;
                System.out.printf("Total do cliente: " + b + "\n");
            }
        }
        m1 = t1/m1;
        m2 = t2/m2;
        System.out.printf("Total do tipo 1: " + t1 + "\n");
        System.out.printf("Total do tipo 2: " + t2 + "\n");
        System.out.printf("Total do tipo 3: " + t3 + "\n");
        System.out.printf("Média do tipo 1: " + m1 + "\n");
        System.out.printf("Média do tipo 2: " + m2 + "\n");
        sc.close();
    }
}