import java.util.Scanner;

public class ex19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Insira o limite superior: ");
        int a = sc.nextInt();
        System.out.printf("Insira o incremento: ");
        int b = sc.nextInt();
        for(int i = 0; i<=a; i+=b){
            System.out.printf(i + " ");
        }
        sc.close();
    }
}