import java.util.Scanner;

public class ex17 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Insira o limite superior: ");
        int a = sc.nextInt();
        System.out.printf("Insira o limite inferior: ");
        int b = sc.nextInt();
        System.out.printf("Insira o incremento: ");
        int c = sc.nextInt();
        for(int i = b; i<=a; i+=c){
            double d = (i * 1.8) + 32;
            System.out.printf("|%d -> %.2f|" + "\n",i,d);
        }
        sc.close();
    }
}