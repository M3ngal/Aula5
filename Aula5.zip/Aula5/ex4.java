import java.util.Scanner;

public class ex4 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String a;
        System.out.printf("Insira um nome: ");
        while(!(a = sc.nextLine()).equals("FIM")){
            System.out.printf(a + "\n");
            System.out.printf("Insira um nome: "); 
            }
        sc.close();
        }
    }