public class ex8 {
    public static void main(String[] args){
        int a = 1;
        for(int i = 2;i<=100;i++){
            a = a + i;
            System.out.printf(a + "\n");
        }
    }
}