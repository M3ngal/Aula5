import java.util.Scanner;

public class ex20 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        for(int i = 0; i<=20; i++) {
            System.out.printf("Insira o nome: ");
            String a = sc.nextLine();
            System.out.printf("Insira a idade: ");
            int b = Integer.parseInt(sc.nextLine());
            System.out.printf("Insira o sexo(M/F): ");
            String c = (sc.nextLine()).toUpperCase();
            if("M".equals(c) && b > 21){
                System.out.printf(a + "\n");
            }
        }
        sc.close();
    }
}