import java.util.Scanner;

public class ex15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Insira um número: ");
        int a = sc.nextInt();
        for (int i = 1; i <= a; i++) {
            System.out.print(fibonacci(i) + ", ");
        }
        sc.close();
    }
    public static int fibonacci(int n) {
        if (n <= 1) {
            return n;
        }
        else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }
}