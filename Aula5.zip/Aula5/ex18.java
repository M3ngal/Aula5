import java.util.Scanner;

public class ex18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Insira um número: ");
        int a = sc.nextInt();
        int b = 1;
        if (a != 0){
            for(int i = 1; i<=a; i++){
                b = b * i;
            }
        }
        System.out.printf("Fatorial: " + b);
        sc.close();
    }
}