import java.util.Scanner;

public class ex2 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int a = 1;
        int b = 0;
        int c = 0;
        while(a > 0){ 
        System.out.printf("Insira um número positivo: ");
        a = sc.nextInt();
        if(a<0){
            break;
        }
        b += a;
        c++;
        }
        double d = b/c;
        System.out.printf("Média: " + d);
        sc.close();
    }
}
