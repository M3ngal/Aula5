import java.util.Scanner;

public class ex21 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Insira o limite superior: ");
        int a = sc.nextInt();
        for(int i = 1; i<=a; i+=2) {
            System.out.printf(i + " ");
        }
        sc.close();
    }
}
