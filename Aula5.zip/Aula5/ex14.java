import java.util.Scanner;

public class ex14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int b = 0;
        while (true) {
            System.out.printf("Insira um número: ");
            int a = sc.nextInt();
            if(a == -9999) {
                break;
            }
            if(a > b){
                b = a;
            }
        }
    System.out.printf("Maior: " + b);
    sc.close();
    }
}