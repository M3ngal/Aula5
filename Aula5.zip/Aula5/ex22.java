import java.util.Scanner;

public class ex22 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.printf("Quantos números?: ");
        int a = sc.nextInt();
        int b = 2;
        for(int i = 0; i<a; i++) {
            System.out.printf(b + " ");
            b += 2;
        }
        sc.close();
    }
}
