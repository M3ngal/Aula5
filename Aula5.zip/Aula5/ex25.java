import java.util.Scanner;

public class ex25 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double d = 0;
        while(true) {
            System.out.printf("Insira um número: ");
            double a = sc.nextDouble();
            System.out.printf("Insira um número: ");
            double b = sc.nextDouble();
            System.out.printf("Operações Disponíveis: \n");
            System.out.printf("1. Adição;\n");
            System.out.printf("2. Subtração;\n");
            System.out.printf("3. Multiplicação;\n");
            System.out.printf("4. Divisão;\n");
            System.out.printf("9. Sair do Programa.\n");
            System.out.printf("Digite o número de ordem da opção desejada: ");
            int c = sc.nextInt();
            if(c == 9){
                break;
            }
            switch (c) {
                case (1):
                    d = a + b;
                    System.out.printf(d + "\n");
                    break;
                case (2):
                    d = a - b;
                    System.out.printf(d + "\n");
                    break;
                case (3):
                    d = a * b;
                    System.out.printf(d + "\n");
                    break;
                case (4):
                    d = a / b;
                    System.out.printf(d + "\n");
                    break;
            }
        }
        sc.close();
    }
}
