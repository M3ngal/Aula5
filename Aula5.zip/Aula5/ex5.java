import java.util.Scanner;

public class ex5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double a;
        System.out.printf("Insira um número: ");
        while((a = sc.nextDouble()) != -999){
            System.out.printf("Raiz quadrada: " + Math.sqrt(a) + "\n");
            System.out.printf("Inverso: " + Math.pow(a,-1) + "\n");
            System.out.printf("Insira um número: "); 
            }
        sc.close();
        }
    }