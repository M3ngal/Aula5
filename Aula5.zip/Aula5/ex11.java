import java.util.Scanner;

public class ex11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int t1 = 0;
        int t2 = 0;
        while(true) {
            System.out.printf("Insira uma idade: ");
            int a = sc.nextInt();
            if(a < 0 || a > 120){
                break;
            }
            if(a < 21){
                t1++;
            }
            else if(a > 50){
                t2++;
            }
        }
        System.out.printf("Total de menores de 21: " + t1 + "\n");
        System.out.printf("Total de maiores de 50: " + t2);
        sc.close();
    }
}