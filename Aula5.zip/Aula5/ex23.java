import java.util.Scanner;

public class ex23 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double a = 0;
        int b = 0;
        double t = 0;
        while(true){
            while(true) {
                System.out.printf("Valor da mercadoria: ");
                a = sc.nextDouble();
                if (a > 0){
                    break;
                }
                System.out.printf("Insira um valor válido");
            }
            while(true) {
                System.out.printf("Quantidade da mercadoria: ");
                b = sc.nextInt();
                if (b > 0){
                    break;
                }
                System.out.printf("Insira um valor válido");
            }
            if(b == 0){
                break;
            }
            t = t + (a * b);
        }
        System.out.printf("Total das mercadorias: " + t);
        sc.close();
    }
}