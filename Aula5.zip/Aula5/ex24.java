import java.util.Scanner;

public class ex24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double t1 = 0;
        double t2 = 0;
        double t3 = 0;
        double t4 = 0;
        double t = 0;
        while(true){
                System.out.printf("Insira o voto: ");
                int a = sc.nextInt();
                if (a == 1){
                    t1++;
                }
                else if (a == 2){
                    t2++;
                }
                else if (a == 3){
                    t3++;
                }
                else if (a == 4){
                    t4++;
                }
                else if (a == -1){
                    break;
                }
                t++;
        }
        t1 = (t1 * 100)/t;
        t2 = (t2 * 100)/t;
        t3 = (t3 * 100)/t;
        t4 = (t4 * 100)/t;

        System.out.printf("Porcemtagem do 1: %.2f", t1);
        System.out.printf("Porcemtagem do 2: %.2f", t2);
        System.out.printf("Porcemtagem do 3: %.2f", t3);
        System.out.printf("Porcemtagem do 4: %.2f", t4);
        System.out.printf("Total de votos: %.2f", t);
        sc.close();
    }
}