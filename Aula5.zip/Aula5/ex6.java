public class ex6 {
    public static void main(String[] args){
        int a = 0;
        while(a != 500){
            a += 5;
            System.out.printf(a + "\n");
        }
    }
}