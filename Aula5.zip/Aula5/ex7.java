public class ex7 {
    public static void main(String[] args){
        int a = 120;
        for(int i = 121;i<=300;i++){
            a = a * i;
            System.out.printf(a + "\n");
        }
    }
}