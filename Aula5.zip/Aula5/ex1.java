public class ex1 {
    public static void main(String[] args){
        int a = 0;
        for(int i = 0; i<=10; i++){
            System.out.printf(a + "\n");
            a += 2;
        }
    }
}